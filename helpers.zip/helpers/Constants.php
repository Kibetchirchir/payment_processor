<?php

/**
 * Created by PhpStorm.
 * User: Kibet
 * Date: 27-Apr-17
 * Time: 4:30 PM
 */
class Constants
{
    const USER_TYPE_PARENT = 1;
    const USER_TYPE_CHILD = 2;

}