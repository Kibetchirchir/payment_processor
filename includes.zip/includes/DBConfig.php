<?php

/**
 * Created by PhpStorm.
 * User: Kibet
 * Date: 27-Apr-17
 * Time: 4:01 PM
 */
class DBConfig
{
    public $host='localhost';
    public $user='ticketso_nouveta';
    public $password='Network97';

    public $database='ticketso_payme';
}
